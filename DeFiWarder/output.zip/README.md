# IDWDetector

IDWDetector is a tools that combines DeFi-semantics-aware sanitizer and fuzzing to detect vulnerabilities in DeFi apps.

IDWDetector is implemented on the top of Ethereum substate recorder/replayer (see [README_Ethereum_Substate.md](README_Ethereum_Substate.md)).

## Building the source

For prerequisites and detailed build instructions please read the [Installation Instructions](https://geth.ethereum.org/docs/install-and-build/installing-geth).

Building `geth` requires both a Go (version 1.14 or later) and a C compiler. You can install
them using your favourite package manager. Once the dependencies are installed, run

```shell
make geth
```

or, to build the full suite of utilities:

```shell
make all
```

## Usage

### Replay transactions
Replay the historical transactions and record the related transactions for further analysis.
```
go run cmd/substate-cli/main.go replay-hunter all <start_block> <end_block>  --substatedir /disk2/substate.ethereum8-15/substate.ethereum --skip-create-txs --skip-transfer-txs --workers 10
```

### Analyze transactions
```
go run hunter/main.go
```

### Prepare for testing
Replay the historical transactions and record the related subsate for testing.
```
go run cmd/substate-cli/main.go seed-generation <start_block> <end_block>  --substatedir /disk2/substate.ethereum8-15/substate.ethereum --skip-create-txs --skip-transfer-txs --workers 10
```

### Test

```
go run cmd/substate-cli/main.go test-hunter <dapp> <block> <threads> --substatedir /disk2/substate.ethereum8-15/substate.ethereum
```

### Data Note